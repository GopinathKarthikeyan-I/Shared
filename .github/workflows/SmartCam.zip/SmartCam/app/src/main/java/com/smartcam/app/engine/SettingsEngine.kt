package com.smartcam.app.engine

import com.smartcam.app.model.CameraCaps
import com.smartcam.app.model.EnvironmentInfo
import com.smartcam.app.model.FocusMode
import com.smartcam.app.model.ImageStats
import com.smartcam.app.model.Look
import com.smartcam.app.model.MeteringInfo
import com.smartcam.app.model.Preset
import com.smartcam.app.model.Recommendation
import com.smartcam.app.model.ReferenceProfile
import com.smartcam.app.model.SceneInfo
import com.smartcam.app.model.ShotSettings
import com.smartcam.app.model.SunPhase
import com.smartcam.app.model.WeatherCondition
import com.smartcam.app.util.ColorMath
import com.smartcam.app.util.Exposure
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Turns "what the camera sees + what the weather/sun/motion sensors say + chosen style" into
 * concrete ISO / shutter / white balance / focus values.
 *
 * Strategy:
 *  1. Start from the camera's own auto-exposure measurement (reliable overall brightness).
 *  2. Decide an EV bias: histogram protection (slow, stable controller) + weather + sun + preset.
 *  3. Re-distribute the exposure between ISO and shutter speed according to the preset,
 *     hand-shake limit (focal length aware), subject motion and tripod detection.
 *  4. White balance from the AWB estimate, nudged for the light quality (overcast, golden, blue).
 *  5. For "Match photo", aim at the reference photo's brightness, colour cast and look.
 *
 * Pure Kotlin: no Android calls, so it is unit-tested on the JVM.
 */
class SettingsEngine {

    /** Integrator for histogram-based correction; keeps the result from oscillating. */
    private var histTerm = 0f

    data class Input(
        val preset: Preset,
        val metering: MeteringInfo,
        val scene: SceneInfo,
        val env: EnvironmentInfo,
        val caps: CameraCaps,
        val reference: ReferenceProfile?,
        val maxIso: Int,
        val zoom: Float,
        val presetLooks: Boolean,
        val nowMillis: Long,
    )

    fun reset() { histTerm = 0f }

    fun compute(i: Input): Recommendation {
        val reasons = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        val pro = mutableListOf<String>()
        val edit = mutableListOf<String>()
        val st = i.scene.stats
        val env = i.env
        val caps = i.caps
        val preset = if (i.preset == Preset.MATCH && i.reference == null) Preset.AUTO else i.preset

        val sun = env.sun
        val wx = env.weather?.takeIf { i.nowMillis - it.fetchedAt < 3 * 3600_000L }
        val daylightByClock = sun?.let { it.elevationDeg > 3 } ?: (wx?.isDay ?: true)
        // Light sensor sits on the front of the phone: outdoors in daytime it reads thousands of lux.
        val indoor = env.lux != null && daylightByClock && env.lux < 700f
        val outdoor = !indoor
        if (indoor) reasons += "Indoor light (${env.lux?.roundToInt()} lx): weather ignored"

        // ---------- 1. Histogram controller ----------
        if (st.highlightClip > 0.03f) histTerm -= 0.15f
        else if (st.highlightClip < 0.008f && histTerm < 0f) histTerm += 0.08f
        if (st.shadowClip > 0.30f && st.highlightClip < 0.005f && histTerm < 0.5f) histTerm += 0.08f
        else if (st.shadowClip < 0.15f && histTerm > 0f) histTerm -= 0.05f
        histTerm = histTerm.coerceIn(-1.7f, 0.7f)
        if (histTerm < -0.2f) reasons += "Protecting bright highlights (${Exposure.formatEv(histTerm)} EV)"
        if (histTerm > 0.2f) reasons += "Lifting deep shadows (${Exposure.formatEv(histTerm)} EV)"

        // ---------- 2. EV bias from light quality ----------
        var baseEv = 0f
        var wbShiftK = 0.0
        if (outdoor && wx != null) when (wx.condition) {
            WeatherCondition.SNOW -> { baseEv += 0.7f; wbShiftK += 200; reasons += "Snow: +0.7 EV so white stays white" }
            WeatherCondition.FOG -> { baseEv += 0.3f; wbShiftK += 300; reasons += "Fog/haze: +0.3 EV, slightly warmer" }
            WeatherCondition.OVERCAST -> { baseEv += 0.3f; wbShiftK += 400; reasons += "Overcast: +0.3 EV, warming WB +400K" }
            WeatherCondition.RAIN, WeatherCondition.STORM -> { wbShiftK += 400; reasons += "Rain: warmer WB, faster shutter" }
            WeatherCondition.PARTLY, WeatherCondition.CLEAR -> Unit
        }
        if (outdoor && sun != null) when (sun.phase) {
            SunPhase.HIGH_SUN -> if (wx == null || wx.cloudCover < 40) {
                baseEv -= 0.3f; reasons += "Harsh overhead sun: -0.3 EV"
                pro += "Harsh light: shoot RAW (or Expert RAW) to keep sky and shadows"
            }
            SunPhase.GOLDEN_HOUR -> { baseEv -= 0.3f; wbShiftK += 700; reasons += "Golden hour: keep the warm glow (-0.3 EV, +700K)" }
            SunPhase.BLUE_HOUR -> { baseEv -= 0.3f; wbShiftK -= 500; reasons += "Blue hour: keep the blue (-500K)" }
            SunPhase.NIGHT -> { baseEv -= 0.5f; reasons += "Night: -0.5 EV so it still looks like night" }
            SunPhase.DAY -> Unit
        }
        when (preset) {
            Preset.GOLDEN -> if (sun?.phase != SunPhase.GOLDEN_HOUR) { baseEv -= 0.3f; wbShiftK += 700 }
            Preset.PORTRAIT -> wbShiftK += 200
            Preset.NIGHT -> if (sun?.phase != SunPhase.NIGHT || indoor) baseEv -= 0.3f
            else -> Unit
        }

        var ev = baseEv + histTerm

        // ---------- Match photo: brightness ----------
        val ref = i.reference?.takeIf { preset == Preset.MATCH }
        if (ref != null) {
            val delta = Exposure.log2(linear(ref.stats.meanLuma) / linear(st.meanLuma))
            ev = (i.metering.evComp + 0.6 * delta).toFloat()   // damped: preview already has evComp
            reasons += "Matching reference brightness (${Exposure.formatEv(ev)} EV)"
        }

        val evMin = caps.evMinSteps * caps.evStep
        val evMax = caps.evMaxSteps * caps.evStep
        ev = ev.coerceIn(maxOf(-2.5f, evMin), minOf(2.0f, evMax))
        val evQuant = (ev / caps.evStep).roundToInt() * caps.evStep

        // ---------- 3. ISO / shutter distribution ----------
        val m = if (i.metering.valid) i.metering else MeteringInfo(100, 16_666_666L, 0f, null, 0f, false)
        val amount = m.iso.toDouble() * m.exposureNs * 2.0.pow((ev - m.evComp).toDouble()) // ISO·ns

        val focalEq = caps.focal35 * i.zoom.coerceAtLeast(1f)
        val handheldS = (2.0 / focalEq).coerceIn(1 / 500.0, 1 / 15.0) // OIS ~1 stop, conservative
        val subjectMotion = if (env.shake < 0.10f) i.scene.motion else 0f
        val motionLimit = when {
            subjectMotion > 0.08f -> 1 / 500.0
            subjectMotion > 0.03f -> 1 / 250.0
            subjectMotion > 0.012f -> 1 / 125.0
            else -> Double.MAX_VALUE
        }
        if (motionLimit < 1.0) reasons += "Moving subject: shutter ≤ ${Exposure.formatShutter((motionLimit * 1e9).toLong())}"
        if (env.steady) reasons += "Phone is steady: slower shutter allowed"

        val maxExpS = caps.expRangeNs.last / 1e9
        var tMax: Double
        var isoCap = i.maxIso
        var frames = 1
        val focus = FocusMode.CONTINUOUS
        when (preset) {
            Preset.PORTRAIT -> {
                tMax = min(min(handheldS, 1 / 125.0), motionLimit)
                pro += "Use the 3x lens for a flattering portrait perspective"
            }
            Preset.LANDSCAPE -> {
                tMax = if (env.steady) min(2.0, maxExpS) else handheldS
                pro += "Focus: MF to ∞ for distant scenery"
            }
            Preset.SPORTS -> {
                tMax = if (subjectMotion > 0.08f) 1 / 2000.0 else 1 / 1000.0
                isoCap = maxOf(i.maxIso, 6400)
                pro += "Hold the shutter for a burst"
            }
            Preset.NIGHT -> if (env.steady) {
                tMax = min(10.0, maxExpS); isoCap = min(i.maxIso, 800)
                reasons += "Tripod/steady night: long exposure, low ISO"
            } else {
                tMax = handheldS; isoCap = maxOf(i.maxIso, 6400); frames = 6
                reasons += "Handheld night: 6 frames aligned and averaged to cut noise"
            }
            else -> tMax = min(if (env.steady) 0.5 else handheldS, motionLimit)
        }
        if (wx != null && outdoor && (wx.condition == WeatherCondition.RAIN || wx.condition == WeatherCondition.STORM)) {
            tMax = min(tMax, 1 / 250.0)
        }

        // Reference photo shutter style: long exposure blur or freeze action.
        if (ref?.exifExposureS != null) {
            val s = ref.exifExposureS
            if (s >= 0.25 && env.steady) { tMax = min(s, maxExpS); reasons += "Reference uses long exposure: ${Exposure.formatShutter((s * 1e9).toLong())}" }
            else if (s >= 0.25) warnings += "Reference is a long exposure – rest the phone on something to copy it"
            else if (s <= 1 / 1000.0) { tMax = min(tMax, s); reasons += "Reference freezes motion: fast shutter" }
        }

        val baseIso = caps.baseIso.toDouble()
        var iso = baseIso
        var t = amount / iso / 1e9
        val wantLong = ref?.exifExposureS?.let { it >= 0.25 && env.steady } == true
        if (wantLong) {
            t = tMax; iso = amount / (t * 1e9)
            if (iso < baseIso * 0.7) { iso = baseIso; warnings += "Too bright for that long exposure – would need an ND filter" }
        }
        if (t > tMax) { t = tMax; iso = amount / (t * 1e9) }
        if (iso > isoCap) {
            iso = isoCap.toDouble()
            t = amount / (iso * 1e9)
            if (t > tMax * 2) {
                t = tMax * 2
                warnings += "Very dark: photo will be under-exposed. Use a tripod or the Night preset"
            }
        }
        val minExpS = caps.expRangeNs.first / 1e9
        if (t < minExpS) { t = minExpS; if (iso <= baseIso) warnings += "Extremely bright: may be over-exposed" }
        iso = iso.coerceIn(caps.isoRange.first.toDouble(), caps.isoRange.last.toDouble())
        t = t.coerceIn(minExpS, maxExpS)
        val isoR = Exposure.roundIso(iso.roundToInt()).coerceIn(caps.isoRange.first, caps.isoRange.last)
        val tNs = Exposure.roundShutterNs((t * 1e9).toLong()).coerceIn(caps.expRangeNs.first, caps.expRangeNs.last)
        if (isoR >= 3200) warnings += "High ISO $isoR: expect some grain"

        // ---------- 4. White balance ----------
        val awb = (m.awbKelvin ?: 5200).toDouble()
        var k = awb + wbShiftK
        if (ref != null) {
            val delta = 0.85 * (ColorMath.mired(ref.stats.castKelvin.toDouble()) - ColorMath.mired(st.castKelvin.toDouble()))
            k = ColorMath.fromMired((ColorMath.mired(awb) - delta).coerceIn(80.0, 500.0))
            reasons += "Matching reference colour (${ref.stats.castKelvin}K look)"
        }
        val kR = ((k.coerceIn(2300.0, 10000.0) / 100).roundToInt() * 100)
        val wbKelvin: Int? = if (caps.manualPostProcessing) kR else null
        if (!caps.manualPostProcessing) warnings += "This lens doesn't allow manual white balance"
        if (!caps.manualSensor) warnings += "This lens doesn't allow manual ISO/shutter – using EV only"

        // ---------- 5. Look ----------
        var look: Look? = null
        if (ref != null) {
            look = Look(
                contrast = (ref.stats.stdLuma / st.stdLuma.coerceAtLeast(0.02f)).coerceIn(0.7f, 1.4f),
                saturation = (ref.stats.meanSat / st.meanSat.coerceAtLeast(0.03f)).coerceIn(0.5f, 1.6f),
            )
        } else if (i.presetLooks) {
            look = when (preset) {
                Preset.LANDSCAPE -> Look(contrast = 1.06f, saturation = 1.12f)
                Preset.GOLDEN -> Look(warmth = 0.25f, saturation = 1.08f)
                Preset.PORTRAIT -> Look(contrast = 0.97f, saturation = 0.96f, warmth = 0.08f)
                Preset.NIGHT, Preset.SPORTS -> Look(contrast = 1.05f)
                else -> null
            }
        }
        if (look?.isNeutral == true) look = null
        look?.let {
            fun pct(v: Float) = ((v - 1f) * 100).roundToInt()
            if (abs(it.saturation - 1f) > 0.02f) edit += "Saturation ${signed(pct(it.saturation))}"
            if (abs(it.contrast - 1f) > 0.02f) edit += "Contrast ${signed(pct(it.contrast))}"
            if (abs(it.warmth) > 0.02f) edit += "Warmth ${signed((it.warmth * 50).roundToInt())}"
        }

        // ---------- Samsung Pro-mode advice ----------
        val proValues = mutableListOf(
            "ISO $isoR",
            "Speed ${Exposure.formatShutter(tNs)}",
            "WB ${kR}K",
            when (preset) {
                Preset.LANDSCAPE -> "Focus: MF ∞"
                Preset.PORTRAIT -> "Focus: AF on the eyes"
                else -> "Focus: AF"
            },
            when {
                preset == Preset.PORTRAIT -> "Metering: Spot (on the face)"
                st.highlightClip > 0.02f && st.p95 - st.p05 > 0.8f -> "Metering: Center-weighted (strong backlight)"
                else -> "Metering: Matrix"
            },
        )
        if (st.p05 < 0.03f && st.p95 > 0.97f) pro += "High-contrast scene: Expert RAW / HDR will hold more detail"
        if (frames > 1) pro += "Handheld at night, Samsung's Night mode is a strong alternative"
        pro.addAll(0, proValues)

        val shot = ShotSettings(
            iso = isoR, exposureNs = tNs, wbKelvin = wbKelvin, evBias = evQuant,
            focus = focus, stackFrames = frames,
        )
        return Recommendation(shot, evQuant, look, reasons, pro, edit, warnings.distinct())
    }

    private fun linear(gammaLuma: Float): Double = gammaLuma.coerceIn(0.01f, 0.99f).toDouble().pow(2.2)
    private fun signed(v: Int) = if (v > 0) "+$v" else "$v"

    companion object {
        /** How far the scene is from "correct" exposure; used by the manual-mode light meter. */
        fun meterOffsetEv(stats: ImageStats): Float =
            (ln(stats.meanLuma.coerceIn(0.01f, 0.99f).toDouble().pow(2.2) / 0.18) / ln(2.0)).toFloat()
    }
}
