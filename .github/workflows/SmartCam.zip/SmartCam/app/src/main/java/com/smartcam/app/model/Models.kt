package com.smartcam.app.model

import android.util.Size

/** Shooting styles. Each one changes how the engine spends the available light. */
enum class Preset(val label: String) {
    AUTO("Smart Auto"),
    PORTRAIT("Portrait"),
    LANDSCAPE("Landscape"),
    NIGHT("Night"),
    SPORTS("Sports"),
    GOLDEN("Golden hour"),
    MATCH("Match photo"),
}

enum class FocusMode { CONTINUOUS, MANUAL, INFINITY }

/** Everything needed to take one still. */
data class ShotSettings(
    val iso: Int,
    val exposureNs: Long,
    val wbKelvin: Int?,          // null = camera auto white balance
    val evBias: Float = 0f,      // only used when the lens has no manual sensor control
    val focus: FocusMode = FocusMode.CONTINUOUS,
    val focusDiopters: Float = 0f,
    val stackFrames: Int = 1,
)

/** What the camera's own auto-exposure / AWB measured on the latest preview frame. */
data class MeteringInfo(
    val iso: Int = 100,
    val exposureNs: Long = 10_000_000L,
    val evComp: Float = 0f,       // EV compensation that was active for this measurement
    val awbKelvin: Int? = null,   // illuminant estimated from the AWB gains
    val focusDiopters: Float = 0f,
    val valid: Boolean = false,
)

/** Brightness / colour statistics of an image (live preview or reference photo). */
data class ImageStats(
    val meanLuma: Float = 0.45f,   // gamma-encoded, 0..1
    val stdLuma: Float = 0.2f,
    val p05: Float = 0.05f,
    val p95: Float = 0.9f,
    val meanSat: Float = 0.3f,
    val castKelvin: Int = 6500,    // apparent colour cast; 6500 = neutral, lower = warmer
    val highlightClip: Float = 0f, // fraction of pixels near white
    val shadowClip: Float = 0f,    // fraction of pixels near black
)

data class SceneInfo(
    val stats: ImageStats = ImageStats(),
    val motion: Float = 0f,        // 0 = static, ~0.1+ = clear subject motion
)

enum class SunPhase(val label: String) {
    NIGHT("Night"), BLUE_HOUR("Blue hour"), GOLDEN_HOUR("Golden hour"), DAY("Daylight"), HIGH_SUN("Harsh sun")
}

data class SunInfo(val elevationDeg: Double, val phase: SunPhase)

enum class WeatherCondition(val label: String) {
    CLEAR("Clear"), PARTLY("Partly cloudy"), OVERCAST("Overcast"), FOG("Fog / haze"),
    RAIN("Rain"), SNOW("Snow"), STORM("Thunderstorm");

    companion object {
        /** WMO weather codes as returned by Open-Meteo. */
        fun from(code: Int, cloudCover: Int): WeatherCondition = when (code) {
            45, 48 -> FOG
            in 51..67, in 80..82 -> RAIN
            in 71..77, 85, 86 -> SNOW
            in 95..99 -> STORM
            else -> when {
                cloudCover >= 75 -> OVERCAST
                cloudCover >= 30 -> PARTLY
                else -> CLEAR
            }
        }
    }
}

data class Weather(
    val cloudCover: Int,
    val code: Int,
    val isDay: Boolean,
    val tempC: Double,
    val humidity: Int,
    val fetchedAt: Long,
) {
    val condition: WeatherCondition get() = WeatherCondition.from(code, cloudCover)
}

data class EnvironmentInfo(
    val lux: Float? = null,
    val shake: Float = 1f,        // smoothed gyro magnitude, rad/s
    val weather: Weather? = null,
    val sun: SunInfo? = null,
) {
    /** Phone resting on something / tripod. */
    val steady: Boolean get() = shake < 0.025f
}

/** Post-capture colour look (used for Match photo and optional preset looks). */
data class Look(
    val brightness: Float = 0f,  // -0.3..0.3 (added, 0..1 scale)
    val contrast: Float = 1f,    // 0.6..1.5
    val saturation: Float = 1f,  // 0.4..1.7
    val warmth: Float = 0f,      // -1..1
    val tint: Float = 0f,        // -1..1 (+ = magenta)
) {
    val isNeutral: Boolean
        get() = kotlin.math.abs(brightness) < 0.01f && kotlin.math.abs(contrast - 1f) < 0.02f &&
            kotlin.math.abs(saturation - 1f) < 0.02f && kotlin.math.abs(warmth) < 0.02f &&
            kotlin.math.abs(tint) < 0.02f
}

/** What we learned from a reference photo the user picked. */
data class ReferenceProfile(
    val stats: ImageStats,
    val exifIso: Int?,
    val exifExposureS: Double?,
    val exifFNumber: Double?,
    val exifFocal35: Int?,
    val exifModel: String?,
    val thumbnailPath: String?,
)

/** Static information about one lens. */
data class CameraCaps(
    val id: String,
    val label: String,
    val facingBack: Boolean,
    val isoRange: IntRange,
    val expRangeNs: LongRange,
    val minFocusDiopters: Float,
    val manualSensor: Boolean,
    val manualPostProcessing: Boolean,
    val rawSize: Size?,
    val jpegSize: Size,
    val previewSize: Size,
    val focal35: Float,
    val zoomMin: Float,
    val zoomMax: Float,
    val sensorOrientation: Int,
    val evMinSteps: Int,
    val evMaxSteps: Int,
    val evStep: Float,
    val baseIso: Int,
)

/** Output of the settings engine. */
data class Recommendation(
    val shot: ShotSettings,
    val previewEv: Float,
    val look: Look?,
    val reasons: List<String>,
    val proTips: List<String>,
    val editTips: List<String>,
    val warnings: List<String>,
)
