package com.smartcam.app.util

import kotlin.math.pow

/** Pure colour-science helpers (no Android dependencies, unit-testable). */
object ColorMath {

    fun srgbToLinear(c: Float): Float =
        if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).toDouble().pow(2.4).toFloat()

    fun linearToSrgb(c: Float): Float =
        if (c <= 0.0031308f) c * 12.92f else (1.055 * c.toDouble().pow(1 / 2.4) - 0.055).toFloat()

    /** Linear sRGB (D65) -> CIE XYZ. */
    fun linearSrgbToXyz(r: Double, g: Double, b: Double): DoubleArray = doubleArrayOf(
        0.4124564 * r + 0.3575761 * g + 0.1804375 * b,
        0.2126729 * r + 0.7151522 * g + 0.0721750 * b,
        0.0193339 * r + 0.1191920 * g + 0.9503041 * b,
    )

    /** McCamy's approximation: CIE xy chromaticity -> correlated colour temperature (K). */
    fun cctFromXy(x: Double, y: Double): Double {
        val n = (x - 0.3320) / (0.1858 - y)
        return 449.0 * n * n * n + 3525.0 * n * n + 6823.3 * n + 5520.33
    }

    fun cctFromXyz(xyz: DoubleArray): Double {
        val sum = xyz[0] + xyz[1] + xyz[2]
        if (sum <= 1e-9) return 6500.0
        return cctFromXy(xyz[0] / sum, xyz[1] / sum)
    }

    /** Kim et al. cubic spline of the Planckian locus: temperature (1667..25000 K) -> CIE xy. */
    fun xyFromCct(kelvin: Double): DoubleArray {
        val t = kelvin.coerceIn(1667.0, 25000.0)
        val x = if (t <= 4000) {
            -0.2661239e9 / (t * t * t) - 0.2343589e6 / (t * t) + 0.8776956e3 / t + 0.179910
        } else {
            -3.0258469e9 / (t * t * t) + 2.1070379e6 / (t * t) + 0.2226347e3 / t + 0.240390
        }
        val y = when {
            t <= 2222 -> -1.1063814 * x * x * x - 1.34811020 * x * x + 2.18555832 * x - 0.20219683
            t <= 4000 -> -0.9549476 * x * x * x - 1.37418593 * x * x + 2.09137015 * x - 0.16748867
            else -> 3.0817580 * x * x * x - 5.87338670 * x * x + 3.75112997 * x - 0.37001483
        }
        return doubleArrayOf(x, y)
    }

    fun xyzFromCct(kelvin: Double): DoubleArray {
        val (x, y) = xyFromCct(kelvin).let { it[0] to it[1] }
        return doubleArrayOf(x / y, 1.0, (1 - x - y) / y)
    }

    /**
     * Apparent colour cast of an image, from gray-world average of linear RGB.
     * A neutral image gives ~6500 K; warm/orange images give lower values, blue images higher.
     */
    fun castKelvin(meanLinR: Double, meanLinG: Double, meanLinB: Double): Int {
        if (meanLinG <= 1e-6) return 6500
        val xyz = linearSrgbToXyz(meanLinR, meanLinG, meanLinB)
        return cctFromXyz(xyz).coerceIn(1800.0, 15000.0).toInt()
    }

    fun mired(kelvin: Double) = 1_000_000.0 / kelvin
    fun fromMired(m: Double) = 1_000_000.0 / m

    // ---- 3x3 matrix helpers (row-major DoubleArray(9)) ----

    fun mul(m: DoubleArray, v: DoubleArray) = doubleArrayOf(
        m[0] * v[0] + m[1] * v[1] + m[2] * v[2],
        m[3] * v[0] + m[4] * v[1] + m[5] * v[2],
        m[6] * v[0] + m[7] * v[1] + m[8] * v[2],
    )

    fun matMul(a: DoubleArray, b: DoubleArray): DoubleArray {
        val r = DoubleArray(9)
        for (i in 0 until 3) for (j in 0 until 3) {
            var s = 0.0
            for (k in 0 until 3) s += a[i * 3 + k] * b[k * 3 + j]
            r[i * 3 + j] = s
        }
        return r
    }

    fun lerp(a: DoubleArray, b: DoubleArray, w: Double) = DoubleArray(a.size) { a[it] * w + b[it] * (1 - w) }

    fun invert(m: DoubleArray): DoubleArray? {
        val a = m[0]; val b = m[1]; val c = m[2]
        val d = m[3]; val e = m[4]; val f = m[5]
        val g = m[6]; val h = m[7]; val i = m[8]
        val det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
        if (kotlin.math.abs(det) < 1e-12) return null
        val inv = 1.0 / det
        return doubleArrayOf(
            (e * i - f * h) * inv, (c * h - b * i) * inv, (b * f - c * e) * inv,
            (f * g - d * i) * inv, (a * i - c * g) * inv, (c * d - a * f) * inv,
            (d * h - e * g) * inv, (b * g - a * h) * inv, (a * e - b * d) * inv,
        )
    }
}
