package com.smartcam.app.env

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import com.smartcam.app.model.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.sqrt

/** Ambient light sensor (indoor/outdoor hint) and gyroscope (tripod / hand-shake detection). */
class EnvSensors(context: Context) : SensorEventListener {
    private val sm = context.getSystemService(SensorManager::class.java)
    private val _lux = MutableStateFlow<Float?>(null)
    private val _shake = MutableStateFlow(1f)
    val lux: StateFlow<Float?> = _lux
    val shake: StateFlow<Float> = _shake

    private var luxEma = -1f
    private var shakeEma = 0.2f
    private var lastShakePost = 0L

    fun start() {
        sm?.getDefaultSensor(Sensor.TYPE_LIGHT)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        sm?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() { sm?.unregisterListener(this) }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_LIGHT -> {
                val v = e.values[0]
                luxEma = if (luxEma < 0) v else 0.7f * luxEma + 0.3f * v
                _lux.value = luxEma
            }
            Sensor.TYPE_GYROSCOPE -> {
                val (x, y, z) = Triple(e.values[0], e.values[1], e.values[2])
                val mag = sqrt(x * x + y * y + z * z)
                shakeEma = 0.92f * shakeEma + 0.08f * mag
                if (e.timestamp - lastShakePost > 200_000_000L) {
                    _shake.value = shakeEma
                    lastShakePost = e.timestamp
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}

/** Coarse location + current weather from Open-Meteo (free, no API key). */
class WeatherService(private val context: Context) {

    @SuppressLint("MissingPermission")
    suspend fun location(): Location? {
        if (context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        val lm = context.getSystemService(LocationManager::class.java) ?: return null
        val providers = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(LocationManager.FUSED_PROVIDER)
            add(LocationManager.NETWORK_PROVIDER)
            add(LocationManager.PASSIVE_PROVIDER)
        }.filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }

        for (p in providers) {
            val loc = withTimeoutOrNull(6_000) {
                suspendCancellableCoroutine<Location?> { cont ->
                    val signal = CancellationSignal()
                    cont.invokeOnCancellation { signal.cancel() }
                    try {
                        lm.getCurrentLocation(p, signal, context.mainExecutor) { l -> if (cont.isActive) cont.resume(l) }
                    } catch (e: Exception) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            }
            if (loc != null) return loc
        }
        return providers.firstNotNullOfOrNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
    }

    suspend fun fetch(lat: Double, lon: Double): Weather? = withContext(Dispatchers.IO) {
        runCatching {
            val url = URL(
                String.format(
                    Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f" +
                        "&current=temperature_2m,relative_humidity_2m,cloud_cover,weather_code,is_day",
                    lat, lon,
                ),
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000; readTimeout = 8_000
            }
            try {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val c = JSONObject(text).getJSONObject("current")
                Weather(
                    cloudCover = c.optInt("cloud_cover", 0),
                    code = c.optInt("weather_code", 0),
                    isDay = c.optInt("is_day", 1) == 1,
                    tempC = c.optDouble("temperature_2m", Double.NaN),
                    humidity = c.optInt("relative_humidity_2m", 0),
                    fetchedAt = System.currentTimeMillis(),
                )
            } finally {
                conn.disconnect()
            }
        }.getOrNull()
    }
}
