package com.smartcam.app.camera

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.hardware.camera2.DngCreator
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import com.smartcam.app.model.Look
import com.smartcam.app.util.Align
import com.smartcam.app.util.LookMatrix
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Saves captures: plain JPEG, night stacks, matched looks and RAW (DNG). */
object PhotoProcessor {

    fun process(ctx: Context, still: StillResult, look: Look?, keepOriginal: Boolean): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val saved = mutableListOf<String>()
        val first = still.jpegs.first()
        val stacked = still.jpegs.size > 1

        if (!stacked && look == null) {
            MediaSaver.save(ctx, "SC_$stamp.jpg", "image/jpeg") { it.write(first) }
            saved += "photo"
        } else {
            if (keepOriginal) {
                MediaSaver.save(ctx, "SC_${stamp}_orig.jpg", "image/jpeg") { it.write(first) }
                saved += "original"
            }
            var bmp = if (stacked) ImageOps.stack(still.jpegs) else ImageOps.decodeUpright(first, 26_000_000)
            if (look != null) {
                val out = ImageOps.applyLook(bmp, look)
                bmp.recycle(); bmp = out
            }
            val tmp = File(ctx.cacheDir, "proc_$stamp.jpg")
            FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            bmp.recycle()
            ImageOps.copyExif(first, tmp)
            MediaSaver.save(ctx, "SC_$stamp.jpg", "image/jpeg") { out -> tmp.inputStream().use { it.copyTo(out) } }
            tmp.delete()
            saved += when {
                stacked && look != null -> "night stack (${still.jpegs.size} frames) + look"
                stacked -> "night stack (${still.jpegs.size} frames)"
                else -> "matched look"
            }
        }

        val raw = still.raw
        if (raw != null) {
            try {
                val result = still.result
                if (result != null) {
                    MediaSaver.save(ctx, "SC_$stamp.dng", "image/x-adobe-dng") { out ->
                        DngCreator(still.characteristics, result).use { dng ->
                            dng.setOrientation(ImageOps.exifOrientation(first))
                            dng.writeImage(out, raw)
                        }
                    }
                    saved += "RAW"
                }
            } finally {
                raw.close()
            }
        }
        return "Saved " + saved.joinToString(" + ") + " to Pictures/SmartCam"
    }
}

object ImageOps {

    fun exifOrientation(jpeg: ByteArray): Int =
        runCatching {
            ExifInterface(ByteArrayInputStream(jpeg)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

    /** Decodes a JPEG, downsampling if above [maxPixels], and rotates it upright. */
    fun decodeUpright(jpeg: ByteArray, maxPixels: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, bounds)
        var sample = 1
        while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > maxPixels) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inMutable = true }
        val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, opts) ?: error("Could not decode photo")
        val degrees = when (exifOrientation(jpeg)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return bmp
        val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
        if (rotated !== bmp) bmp.recycle()
        return rotated
    }

    fun applyLook(src: Bitmap, look: Look): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix(LookMatrix.of(look)))
        }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /**
     * Night stacking: aligns each burst frame to the first (coarse 1/8 then fine 1/2 scale search)
     * and averages them. Averaging N frames reduces noise by about √N.
     */
    fun stack(frames: List<ByteArray>): Bitmap {
        val base = decodeUpright(frames[0], 16_000_000)
        val w = base.width; val h = base.height
        val sum = ShortArray(w * h * 3)
        val row = IntArray(w)
        fun accumulate(bmp: Bitmap, dx: Int, dy: Int) {
            var lastY = -1
            for (y in 0 until h) {
                val sy = (y + dy).coerceIn(0, h - 1)
                if (sy != lastY) { bmp.getPixels(row, 0, w, 0, sy, w, 1); lastY = sy }
                var idx = y * w * 3
                for (x in 0 until w) {
                    val p = row[(x + dx).coerceIn(0, w - 1)]
                    sum[idx] = (sum[idx] + ((p shr 16) and 0xFF)).toShort()
                    sum[idx + 1] = (sum[idx + 1] + ((p shr 8) and 0xFF)).toShort()
                    sum[idx + 2] = (sum[idx + 2] + (p and 0xFF)).toShort()
                    idx += 3
                }
            }
        }
        accumulate(base, 0, 0)
        var used = 1
        val coarseA = luma(base, 8); val fineA = luma(base, 2)
        for (i in 1 until frames.size) {
            val bmp = runCatching { decodeUpright(frames[i], 16_000_000) }.getOrNull() ?: continue
            if (bmp.width != w || bmp.height != h) { bmp.recycle(); continue }
            val coarseB = luma(bmp, 8)
            val (cx, cy) = Align.find(coarseA.data, coarseB.data, coarseA.w, coarseA.h, 0, 0, radius = 12, step = 2)
            val fineB = luma(bmp, 2)
            val (fx, fy) = Align.find(fineA.data, fineB.data, fineA.w, fineA.h, cx * 4, cy * 4, radius = 5, step = 3)
            accumulate(bmp, fx * 2, fy * 2)
            bmp.recycle()
            used++
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        for (y in 0 until h) {
            var idx = y * w * 3
            for (x in 0 until w) {
                val r = sum[idx] / used; val g = sum[idx + 1] / used; val b = sum[idx + 2] / used
                row[x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                idx += 3
            }
            out.setPixels(row, 0, w, 0, y, w, 1)
        }
        base.recycle()
        return out
    }

    private class Luma(val data: FloatArray, val w: Int, val h: Int)

    private fun luma(bmp: Bitmap, factor: Int): Luma {
        val w = (bmp.width / factor).coerceAtLeast(8); val h = (bmp.height / factor).coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(bmp, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== bmp) small.recycle()
        return Luma(FloatArray(px.size) {
            val p = px[it]
            (0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)) / 255f
        }, w, h)
    }

    /** Copies the camera EXIF (ISO, shutter, lens, date…) into a processed JPEG. */
    fun copyExif(fromJpeg: ByteArray, to: File) {
        runCatching {
            val src = ExifInterface(ByteArrayInputStream(fromJpeg))
            val dst = ExifInterface(to.absolutePath)
            for (tag in TAGS) src.getAttribute(tag)?.let { dst.setAttribute(tag, it) }
            dst.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
            dst.setAttribute(ExifInterface.TAG_SOFTWARE, "SmartCam")
            dst.saveAttributes()
        }
    }

    private val TAGS = listOf(
        ExifInterface.TAG_DATETIME, ExifInterface.TAG_DATETIME_ORIGINAL, ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_OFFSET_TIME, ExifInterface.TAG_OFFSET_TIME_ORIGINAL,
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_EXPOSURE_TIME,
        ExifInterface.TAG_F_NUMBER, ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, ExifInterface.TAG_FOCAL_LENGTH,
        ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, ExifInterface.TAG_WHITE_BALANCE, ExifInterface.TAG_FLASH,
        ExifInterface.TAG_EXPOSURE_BIAS_VALUE,
    )
}

object MediaSaver {
    fun save(ctx: Context, name: String, mime: String, write: (OutputStream) -> Unit): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SmartCam")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
            ?: error("Could not create $name")
        try {
            resolver.openOutputStream(uri)?.use(write) ?: error("Could not write $name")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }
}
