package com.smartcam.app.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.SurfaceTexture
import android.provider.MediaStore
import android.view.TextureView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartcam.app.CamViewModel
import com.smartcam.app.Mode
import com.smartcam.app.UiState
import com.smartcam.app.model.Preset
import com.smartcam.app.util.Exposure
import kotlinx.coroutines.delay
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.roundToLong

private val Amber = Color(0xFFFFC857)
private val Dim = Color(0xFFB0B0B0)

@Composable
fun CameraScreen(vm: CamViewModel) {
    val s by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> vm.onStart()
                Lifecycle.Event.ON_STOP -> vm.onStop()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    var textureView by remember { mutableStateOf<TextureView?>(null) }
    var showAdvice by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setReference(uri)
    }

    // Live analysis: small thumbnail of the viewfinder ~2.5 times per second.
    LaunchedEffect(textureView) {
        val tv = textureView ?: return@LaunchedEffect
        val w = 72; val h = 96
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val px = IntArray(w * h)
        while (true) {
            delay(400)
            if (tv.isAvailable) runCatching {
                tv.getBitmap(bmp)
                bmp.getPixels(px, 0, w, 0, 0, w, h)
                vm.onFrame(px.copyOf())
            }
        }
    }
    LaunchedEffect(s.message, s.busy) {
        if (!s.busy && s.message != null) { delay(5000); vm.dismissMessage() }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        StatusLine(s, onSettings = { showSettings = true })

        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f)) {
            AndroidView(
                factory = { c ->
                    TextureView(c).apply {
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) = vm.onSurfaceReady(st)
                            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) = Unit
                            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { vm.onSurfaceDestroyed(); return true }
                            override fun onSurfaceTextureUpdated(st: SurfaceTexture) = Unit
                        }
                        textureView = this
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
            Readout(s, Modifier.align(Alignment.TopStart).padding(8.dp))
            s.reference?.thumbnailPath?.let { path ->
                val img = remember(s.reference) { BitmapFactory.decodeFile(path)?.asImageBitmap() }
                if (img != null && s.preset == Preset.MATCH) {
                    Image(
                        img, contentDescription = "Reference photo", contentScale = ContentScale.Crop,
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(72.dp)
                            .clip(RoundedCornerShape(8.dp)).border(2.dp, Amber, RoundedCornerShape(8.dp))
                            .clickable { vm.clearReference() },
                    )
                }
            }
            if (s.busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
        ) {
            ModeAndLens(s, vm)
            if (s.mode == Mode.SMART) SmartPanel(s, vm) else ManualPanel(s, vm)
        }

        s.message?.let {
            Text(
                it, color = Color.White, fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().background(Color(0xFF222222)).clickable { vm.dismissMessage() }.padding(8.dp),
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Text("Match photo") }
            Box(
                Modifier.size(76.dp).clip(CircleShape).border(4.dp, Color.White, CircleShape).padding(8.dp)
                    .clip(CircleShape).background(if (s.busy) Color.Gray else Color.White)
                    .clickable(enabled = !s.busy) { vm.capture() },
            )
            OutlinedButton(onClick = { showAdvice = true }) { Text("Pro advice") }
        }
    }

    if (showAdvice) AdviceDialog(s, onDismiss = { showAdvice = false }, openSamsung = { openSamsungCamera(ctx) })
    if (showSettings) SettingsDialog(s, vm, onDismiss = { showSettings = false })
}

@Composable
private fun StatusLine(s: UiState, onSettings: () -> Unit) {
    val parts = buildList {
        s.env.weather?.let { w ->
            add(w.condition.label + if (!w.tempC.isNaN()) " ${w.tempC.roundToInt()}°C" else "")
        }
        s.env.sun?.let { add(it.phase.label) }
        s.env.lux?.let { add("${it.roundToInt()} lx") }
        add(if (s.env.steady) "Steady" else "Handheld")
        if (s.rawActive) add("RAW")
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(parts.joinToString("  ·  "), color = Dim, fontSize = 12.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onSettings) { Text("Settings") }
    }
}

@Composable
private fun Readout(s: UiState, modifier: Modifier) {
    Column(modifier.background(Color(0x88000000), RoundedCornerShape(8.dp)).padding(8.dp)) {
        if (s.mode == Mode.SMART) {
            val rec = s.rec
            if (rec == null) {
                Text("Analysing scene…", color = Color.White, fontSize = 13.sp)
            } else {
                val sh = rec.shot
                Text(
                    "ISO ${sh.iso}  ·  ${Exposure.formatShutter(sh.exposureNs)}  ·  ${sh.wbKelvin?.let { "${it}K" } ?: "AWB"}",
                    color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                )
                val extra = buildList {
                    if (rec.previewEv != 0f) add("EV ${Exposure.formatEv(rec.previewEv)}")
                    if (sh.stackFrames > 1) add("${sh.stackFrames}-frame stack")
                    if (rec.look != null) add("+ look")
                }
                if (extra.isNotEmpty()) Text(extra.joinToString("  ·  "), color = Dim, fontSize = 12.sp)
                rec.warnings.take(2).forEach { Text(it, color = Amber, fontSize = 12.sp) }
            }
        } else {
            val m = s.manual
            Text(
                (if (m.autoExposure) "Auto exposure" else "ISO ${m.iso}  ·  ${Exposure.formatShutter(m.exposureNs)}") +
                    "  ·  " + (if (m.autoWb) "AWB" else "${m.wbKelvin}K"),
                color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
            )
            val ev = s.meterEv
            val hint = when {
                ev > 0.7f -> "over-exposed"
                ev < -0.7f -> "under-exposed"
                else -> "about right"
            }
            Text("Meter ${Exposure.formatEv(ev)} EV ($hint)", color = if (kotlin.math.abs(ev) > 0.7f) Amber else Dim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ModeAndLens(s: UiState, vm: CamViewModel) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = s.mode == Mode.SMART, onClick = { vm.setMode(Mode.SMART) }, label = { Text("Smart") })
        FilterChip(selected = s.mode == Mode.MANUAL, onClick = { vm.setMode(Mode.MANUAL) }, label = { Text("Manual") })
        if (s.mode == Mode.SMART && s.rec != null) {
            TextButton(onClick = { vm.smartToManual() }) { Text("Fine-tune →") }
        }
    }
    if (s.cameras.size > 1) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            s.cameras.forEach { c ->
                FilterChip(
                    selected = s.caps?.id == c.id,
                    onClick = { vm.selectCamera(c.id) },
                    label = { Text(c.label.substringBefore(" ·"), fontSize = 12.sp) },
                )
            }
        }
    }
    val caps = s.caps
    if (caps != null && caps.zoomMax > caps.zoomMin + 0.05f) {
        val lo = ln(caps.zoomMin); val hi = ln(caps.zoomMax.coerceAtMost(30f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zoom ${"%.1f".format(s.zoom)}x", color = Color.White, fontSize = 13.sp, modifier = Modifier.width(84.dp))
            Slider(
                value = ln(s.zoom).coerceIn(lo, hi),
                onValueChange = { v: Float -> vm.setZoom(exp(v)) },
                valueRange = lo..hi,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun SmartPanel(s: UiState, vm: CamViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Preset.entries.filter { it != Preset.MATCH || s.reference != null }.forEach { p ->
            FilterChip(selected = s.preset == p, onClick = { vm.setPreset(p) }, label = { Text(p.label) })
        }
    }
    s.rec?.reasons?.take(4)?.forEach { Text("• $it", color = Dim, fontSize = 12.sp) }
}

@Composable
private fun ManualPanel(s: UiState, vm: CamViewModel) {
    val c = s.caps ?: return
    val m = s.manual
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = m.autoExposure, onClick = { vm.updateManual { it.copy(autoExposure = !it.autoExposure) } }, label = { Text("Auto exposure") })
        FilterChip(selected = m.autoWb, onClick = { vm.updateManual { it.copy(autoWb = !it.autoWb) } }, label = { Text("Auto WB") })
        FilterChip(selected = m.autoFocus, onClick = { vm.updateManual { it.copy(autoFocus = !it.autoFocus) } }, label = { Text("AF") })
    }
    if (!m.autoExposure && c.manualSensor) {
        LogSlider("ISO ${m.iso}", m.iso.toDouble(), c.isoRange.first.toDouble(), c.isoRange.last.toDouble()) { v ->
            vm.updateManual { it.copy(iso = Exposure.roundIso(v.roundToInt()).coerceIn(c.isoRange.first, c.isoRange.last)) }
        }
        val maxExp = c.expRangeNs.last.coerceAtMost(30_000_000_000L)
        LogSlider("Shutter ${Exposure.formatShutter(m.exposureNs)}", m.exposureNs.toDouble(), c.expRangeNs.first.toDouble(), maxExp.toDouble()) { v ->
            vm.updateManual { it.copy(exposureNs = Exposure.roundShutterNs(v.roundToLong()).coerceIn(c.expRangeNs.first, maxExp)) }
        }
    }
    if (!m.autoWb && c.manualPostProcessing) {
        LabeledSlider("WB ${m.wbKelvin}K", m.wbKelvin.toFloat(), 2300f..10000f) { v ->
            vm.updateManual { it.copy(wbKelvin = (v / 100).roundToInt() * 100) }
        }
    }
    if (!m.autoFocus && c.minFocusDiopters > 0f) {
        val label = if (m.focusDiopters < 0.05f) "Focus ∞" else "Focus ${"%.2f".format(1f / m.focusDiopters)} m"
        LabeledSlider(label, m.focusDiopters, 0f..c.minFocusDiopters) { v -> vm.updateManual { it.copy(focusDiopters = v) } }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.width(110.dp))
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun LogSlider(label: String, value: Double, min: Double, max: Double, onChange: (Double) -> Unit) {
    val lo = ln(min).toFloat(); val hi = ln(max).toFloat()
    LabeledSlider(label, ln(value).toFloat(), lo..hi) { v: Float -> onChange(exp(v.toDouble())) }
}

@Composable
private fun AdviceDialog(s: UiState, onDismiss: () -> Unit, openSamsung: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onDismiss(); openSamsung() }) { Text("Open Samsung Camera") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Samsung Pro mode settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                val rec = s.rec
                if (s.mode != Mode.SMART || rec == null) {
                    Text("Switch to Smart mode and point at your scene to get advice.")
                } else {
                    Text("Camera → More → Pro, then set:", fontWeight = FontWeight.SemiBold)
                    rec.proTips.forEach { Text("• $it") }
                    if (rec.editTips.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text("After shooting: Gallery → Edit → Adjust", fontWeight = FontWeight.SemiBold)
                        rec.editTips.forEach { Text("• $it") }
                    }
                    if (rec.warnings.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        rec.warnings.forEach { Text("⚠ $it", color = Amber) }
                    }
                    if (rec.reasons.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        HorizontalDivider()
                        Text("Why", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                        rec.reasons.forEach { Text("• $it", fontSize = 13.sp) }
                    }
                }
                s.reference?.let { r ->
                    Spacer(Modifier.height(10.dp))
                    HorizontalDivider()
                    Text("Reference photo", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                    val exif = listOfNotNull(
                        r.exifModel, r.exifIso?.let { "ISO $it" },
                        r.exifExposureS?.let { Exposure.formatShutter((it * 1e9).toLong()) },
                        r.exifFNumber?.let { "f/${"%.1f".format(it)}" }, r.exifFocal35?.let { "${it}mm" },
                    )
                    Text(if (exif.isEmpty()) "No camera data in the file" else exif.joinToString(" · "), fontSize = 13.sp)
                    Text(
                        "Look: ${r.stats.castKelvin}K cast · brightness ${(r.stats.meanLuma * 100).roundToInt()}% · " +
                            "contrast ${(r.stats.stdLuma * 100).roundToInt()} · saturation ${(r.stats.meanSat * 100).roundToInt()}%",
                        fontSize = 13.sp,
                    )
                }
            }
        },
    )
}

@Composable
private fun SettingsDialog(s: UiState, vm: CamViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
        title = { Text("Settings") },
        text = {
            Column {
                SwitchRow("Save RAW (DNG) too", s.rawEnabled) { vm.setRaw(it) }
                SwitchRow("Keep original when a look/stack is applied", s.keepOriginal) { vm.setKeepOriginal(it) }
                SwitchRow("Apply preset colour looks", s.presetLooks) { vm.setPresetLooks(it) }
                Spacer(Modifier.height(8.dp))
                Text("Max ISO in Smart mode")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(800, 1600, 3200, 6400).forEach { v ->
                        FilterChip(selected = s.maxIso == v, onClick = { vm.setMaxIso(v) }, label = { Text("$v") })
                    }
                }
                s.caps?.let { c ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Lens: ${c.label}\nISO ${c.isoRange.first}–${c.isoRange.last} · shutter " +
                            "${Exposure.formatShutter(c.expRangeNs.first)}–${Exposure.formatShutter(c.expRangeNs.last)}\n" +
                            "Manual exposure: ${yn(c.manualSensor)} · manual WB: ${yn(c.manualPostProcessing)} · RAW: ${yn(c.rawSize != null)}",
                        color = Dim, fontSize = 12.sp,
                    )
                }
            }
        },
    )
}

private fun yn(b: Boolean) = if (b) "yes" else "no"

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun openSamsungCamera(ctx: Context) {
    val generic = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        ctx.startActivity(Intent(generic).setPackage("com.sec.android.app.camera"))
    } catch (e: ActivityNotFoundException) {
        runCatching { ctx.startActivity(generic) }
    }
}

