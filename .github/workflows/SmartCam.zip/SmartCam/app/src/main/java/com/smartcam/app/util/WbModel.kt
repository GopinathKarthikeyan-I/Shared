package com.smartcam.app.util

/**
 * Converts between colour temperature (Kelvin) and the sensor's white-balance gains, using the
 * per-device DNG-style calibration the camera publishes (SENSOR_COLOR_TRANSFORM1/2,
 * SENSOR_CALIBRATION_TRANSFORM1/2, SENSOR_REFERENCE_ILLUMINANT1/2).
 *
 * This makes the Kelvin numbers comparable with Samsung Pro mode's WB value instead of being an
 * arbitrary scale. Pure Kotlin so it can be unit-tested on the JVM.
 *
 * Matrices are row-major 3x3 and map CIE XYZ -> camera native RGB.
 */
class WbModel(
    cm1: DoubleArray,
    cm2: DoubleArray?,
    private val t1: Double,
    private val t2: Double,
    cc1: DoubleArray? = null,
    cc2: DoubleArray? = null,
) {
    private val m1 = if (cc1 != null) ColorMath.matMul(cc1, cm1) else cm1
    private val m2 = if (cm2 == null) null else if (cc2 != null) ColorMath.matMul(cc2, cm2) else cm2

    private fun matrixAt(kelvin: Double): DoubleArray {
        val b = m2 ?: return m1
        if (kotlin.math.abs(t1 - t2) < 1) return m1
        // Interpolate in mired space between the two calibration illuminants.
        val w = ((1 / kelvin - 1 / t2) / (1 / t1 - 1 / t2)).coerceIn(0.0, 1.0)
        return ColorMath.lerp(m1, b, w)
    }

    /** Camera-native RGB of a neutral (white) object lit by [kelvin]. */
    fun neutralFor(kelvin: Double): DoubleArray {
        val n = ColorMath.mul(matrixAt(kelvin), ColorMath.xyzFromCct(kelvin))
        return doubleArrayOf(n[0].coerceAtLeast(1e-6), n[1].coerceAtLeast(1e-6), n[2].coerceAtLeast(1e-6))
    }

    /** White-balance gains (R, G, B) normalised so G = 1. */
    fun gainsFor(kelvin: Double): DoubleArray {
        val n = neutralFor(kelvin)
        return doubleArrayOf(n[1] / n[0], 1.0, n[1] / n[2])
    }

    /** Inverse: estimate the illuminant temperature from AWB gains. */
    fun kelvinForGains(r: Double, g: Double, b: Double): Double {
        if (r <= 0 || g <= 0 || b <= 0) return 5500.0
        // The red/blue gain ratio rises monotonically with temperature: bisect in mired space.
        val target = kotlin.math.ln(r / b)
        fun ratio(k: Double) = gainsFor(k).let { kotlin.math.ln(it[0] / it[2]) }
        var loM = ColorMath.mired(15000.0)   // hot end (low mired)
        var hiM = ColorMath.mired(1800.0)    // warm end (high mired)
        if (target >= ratio(15000.0)) return 15000.0
        if (target <= ratio(1800.0)) return 1800.0
        repeat(40) {
            val mid = (loM + hiM) / 2
            if (ratio(ColorMath.fromMired(mid)) > target) loM = mid else hiM = mid
        }
        return ColorMath.fromMired((loM + hiM) / 2)
    }

    companion object {
        /** XYZ -> linear sRGB; used when the device does not publish calibration matrices. */
        val SRGB_FROM_XYZ = doubleArrayOf(
            3.2404542, -1.5371385, -0.4985314,
            -0.9692660, 1.8760108, 0.0415560,
            0.0556434, -0.2040259, 1.0572252,
        )

        fun fallback() = WbModel(SRGB_FROM_XYZ, null, 6504.0, 6504.0)

        /** Approximate temperatures of the EXIF/DNG LightSource codes used by Camera2. */
        fun illuminantKelvin(code: Int): Double = when (code) {
            1, 4, 9 -> 5500.0      // daylight, flash, fine weather
            2, 14 -> 4150.0        // fluorescent, cool white fluorescent
            3, 17 -> 2856.0        // tungsten, standard A
            10 -> 6500.0           // cloudy
            11 -> 7500.0           // shade
            12 -> 6430.0
            13 -> 5000.0
            15 -> 3450.0
            18 -> 4874.0
            19 -> 6774.0
            20 -> 5503.0
            21 -> 6504.0
            22 -> 7504.0
            23 -> 5003.0
            24 -> 3200.0
            else -> 5000.0
        }
    }
}
