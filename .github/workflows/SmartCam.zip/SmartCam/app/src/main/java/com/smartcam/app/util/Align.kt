package com.smartcam.app.util

import kotlin.math.abs

/**
 * Finds the translation that best aligns frame [b] onto [a] (both luma, width [w] × height [h]):
 * returns (dx, dy) such that b(x+dx, y+dy) ≈ a(x, y). Brute-force SAD search over the central
 * part of the image, which is plenty for hand-shake between burst frames. Pure Kotlin.
 */
object Align {
    fun find(
        a: FloatArray, b: FloatArray, w: Int, h: Int,
        centerX: Int = 0, centerY: Int = 0, radius: Int = 12, step: Int = 2,
    ): Pair<Int, Int> {
        val x0 = w / 5; val x1 = w - w / 5
        val y0 = h / 5; val y1 = h - h / 5
        var best = Double.MAX_VALUE
        var bx = centerX; var by = centerY
        for (dy in centerY - radius..centerY + radius) {
            for (dx in centerX - radius..centerX + radius) {
                var sum = 0.0; var n = 0
                var y = y0
                while (y < y1) {
                    val sy = y + dy
                    if (sy in 0 until h) {
                        var x = x0
                        val rowA = y * w; val rowB = sy * w
                        while (x < x1) {
                            val sx = x + dx
                            if (sx in 0 until w) { sum += abs(a[rowA + x] - b[rowB + sx]); n++ }
                            x += step
                        }
                    }
                    y += step
                }
                if (n > 0) {
                    val score = sum / n
                    if (score < best) { best = score; bx = dx; by = dy }
                }
            }
        }
        return bx to by
    }
}
