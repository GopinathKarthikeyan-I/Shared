package com.smartcam.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.smartcam.app.model.ReferenceProfile
import com.smartcam.app.util.ImageStatsCalc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Reads a reference photo: its EXIF settings (if kept) plus brightness/contrast/colour statistics. */
object ReferenceAnalyzer {

    suspend fun analyze(ctx: Context, uri: Uri): ReferenceProfile = withContext(Dispatchers.IO) {
        val cr = ctx.contentResolver
        var iso: Int? = null
        var exposure: Double? = null
        var fNumber: Double? = null
        var focal35: Int? = null
        var model: String? = null
        var rotation = 0f
        runCatching {
            cr.openInputStream(uri)?.use { s ->
                val ex = ExifInterface(s)
                iso = ex.getAttributeInt(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0).takeIf { it > 0 }
                exposure = ex.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0).takeIf { it > 0 }
                fNumber = ex.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0).takeIf { it > 0 }
                focal35 = ex.getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0).takeIf { it > 0 }
                model = listOfNotNull(ex.getAttribute(ExifInterface.TAG_MAKE), ex.getAttribute(ExifInterface.TAG_MODEL))
                    .joinToString(" ").ifBlank { null }
                rotation = ex.rotationDegrees.toFloat()
            }
        }

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 384 && bounds.outHeight / (sample * 2) >= 384) sample *= 2
        val decoded = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: error("Could not read that image")
        val bmp = if (rotation != 0f) {
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(rotation) }, true)
        } else decoded

        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val stats = ImageStatsCalc.compute(px)

        val thumb = File(ctx.cacheDir, "reference_thumb.jpg")
        FileOutputStream(thumb).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        if (bmp !== decoded) decoded.recycle()
        bmp.recycle()

        ReferenceProfile(stats, iso, exposure, fNumber, focal35, model, thumb.absolutePath)
    }
}
