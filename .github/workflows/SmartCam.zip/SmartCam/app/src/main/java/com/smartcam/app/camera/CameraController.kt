package com.smartcam.app.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.ColorSpaceTransform
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.RggbChannelVector
import android.hardware.camera2.params.SessionConfiguration
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import com.smartcam.app.model.CameraCaps
import com.smartcam.app.model.FocusMode
import com.smartcam.app.model.MeteringInfo
import com.smartcam.app.model.ShotSettings
import com.smartcam.app.util.WbModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

/** What the camera should be doing right now (preview) or for one still. */
data class ControlConfig(
    val manual: ShotSettings? = null, // null = auto exposure (with evComp)
    val evComp: Float = 0f,
    val wbKelvin: Int? = null,        // null = auto white balance
    val zoom: Float = 1f,
    val focus: FocusMode = FocusMode.CONTINUOUS,
    val focusDiopters: Float = 0f,
)

class StillResult(
    val jpegs: List<ByteArray>,
    val raw: Image?,
    val result: TotalCaptureResult?,
    val characteristics: CameraCharacteristics,
)

/** Thin coroutine wrapper around Camera2 with full manual control. */
class CameraController(context: Context) {
    private val manager = context.applicationContext.getSystemService(CameraManager::class.java)
    private val thread = HandlerThread("SmartCam-camera").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { handler.post(it) }

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var previewSurface: Surface? = null
    private var characteristics: CameraCharacteristics? = null
    private var caps: CameraCaps? = null
    private var wb: WbModel = WbModel.fallback()
    @Volatile private var awbTransform: ColorSpaceTransform? = null
    @Volatile private var awbGains: DoubleArray? = null   // last gains chosen by the camera's AWB
    @Volatile private var awbKelvinExact: Double? = null
    @Volatile private var config = ControlConfig()
    private var frameCounter = 0

    private val jpegs = Channel<ByteArray>(Channel.UNLIMITED)
    private val raws = Channel<Image>(Channel.UNLIMITED)

    private val _metering = MutableStateFlow(MeteringInfo())
    val metering: StateFlow<MeteringInfo> = _metering

    val rawActive: Boolean get() = rawReader != null

    fun listCameras(): List<CameraCaps> = CapsReader.listCameras(manager)

    suspend fun open(id: String, texture: SurfaceTexture, wantRaw: Boolean): CameraCaps {
        close()
        val ch = manager.getCameraCharacteristics(id)
        val c = CapsReader.read(id, ch)
        characteristics = ch; caps = c; wb = CapsReader.wbModel(ch)
        awbTransform = null; awbGains = null; awbKelvinExact = null
        _metering.value = MeteringInfo()

        texture.setDefaultBufferSize(c.previewSize.width, c.previewSize.height)
        val ps = Surface(texture).also { previewSurface = it }
        val jr = ImageReader.newInstance(c.jpegSize.width, c.jpegSize.height, ImageFormat.JPEG, 4)
        jr.setOnImageAvailableListener({ r ->
            val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
            try {
                val buf = img.planes[0].buffer
                val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                jpegs.trySend(bytes)
            } finally { img.close() }
        }, handler)
        jpegReader = jr

        val dev = openDevice(id).also { device = it }
        var rr: ImageReader? = null
        if (wantRaw && c.rawSize != null) {
            rr = ImageReader.newInstance(c.rawSize.width, c.rawSize.height, ImageFormat.RAW_SENSOR, 3)
            rr.setOnImageAvailableListener({ r -> r.acquireNextImage()?.let { raws.trySend(it) } }, handler)
        }
        session = try {
            createSession(dev, listOfNotNull(ps, jr.surface, rr?.surface)).also { rawReader = rr }
        } catch (e: Exception) {
            if (rr == null) throw e
            Log.w(TAG, "RAW session failed, retrying without RAW", e)
            rr.close(); rawReader = null
            createSession(dev, listOf(ps, jr.surface))
        }
        handler.post { startPreview() }
        return c
    }

    fun close() {
        runCatching { session?.close() }; session = null
        runCatching { device?.close() }; device = null
        runCatching { jpegReader?.close() }; jpegReader = null
        runCatching { rawReader?.close() }; rawReader = null
        runCatching { previewSurface?.release() }; previewSurface = null
    }

    fun release() { close(); thread.quitSafely() }

    fun setConfig(cfg: ControlConfig) {
        if (cfg == config) return
        config = cfg
        handler.post { startPreview() }
    }

    // ---------------------------------------------------------------- internals

    @SuppressLint("MissingPermission")
    private suspend fun openDevice(id: String): CameraDevice = suspendCancellableCoroutine { cont ->
        manager.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { if (cont.isActive) cont.resume(d) else d.close() }
            override fun onDisconnected(d: CameraDevice) {
                d.close()
                if (cont.isActive) cont.resumeWithException(IllegalStateException("Camera disconnected"))
            }
            override fun onError(d: CameraDevice, error: Int) {
                d.close()
                if (cont.isActive) cont.resumeWithException(IllegalStateException("Camera error $error"))
            }
        }, handler)
    }

    private suspend fun createSession(dev: CameraDevice, surfaces: List<Surface>): CameraCaptureSession =
        suspendCancellableCoroutine { cont ->
            val cfg = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                surfaces.map { OutputConfiguration(it) },
                executor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) { if (cont.isActive) cont.resume(s) else s.close() }
                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        if (cont.isActive) cont.resumeWithException(IllegalStateException("Session configuration failed"))
                    }
                },
            )
            dev.createCaptureSession(cfg)
        }

    private fun startPreview() {
        val s = session ?: return
        val d = device ?: return
        val ps = previewSurface ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(ps)
            applyControls(b, config, forPreview = true)
            s.setRepeatingRequest(b.build(), meterCallback, handler)
        } catch (e: Exception) {
            Log.w(TAG, "preview request failed", e)
        }
    }

    private fun applyControls(b: CaptureRequest.Builder, cfg: ControlConfig, forPreview: Boolean) {
        val c = caps ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        if (c.zoomMax > c.zoomMin) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, cfg.zoom.coerceIn(c.zoomMin, c.zoomMax))

        // Exposure
        val m = cfg.manual
        if (m != null && c.manualSensor) {
            var exp = m.exposureNs.coerceIn(c.expRangeNs.first, c.expRangeNs.last)
            var iso = m.iso.coerceIn(c.isoRange.first, c.isoRange.last)
            if (forPreview && exp > PREVIEW_MAX_EXPOSURE_NS) {
                // Keep the viewfinder fluid: same brightness, shorter exposure, higher gain.
                val factor = exp.toDouble() / PREVIEW_MAX_EXPOSURE_NS
                exp = PREVIEW_MAX_EXPOSURE_NS
                iso = (iso * factor).roundToInt().coerceIn(c.isoRange.first, c.isoRange.last)
            }
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, exp)
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            val ev = m?.evBias ?: cfg.evComp
            val steps = (ev / c.evStep).roundToInt().coerceIn(c.evMinSteps, c.evMaxSteps)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, steps)
        }

        // White balance
        val k = cfg.wbKelvin
        if (k != null && c.manualPostProcessing) {
            // Relative to what the camera's AWB measured: a 0 K shift reproduces AWB exactly,
            // so colours stay right even when the lens publishes no colour calibration.
            val target = wb.gainsFor(k.toDouble())
            val ag = awbGains; val ak = awbKelvinExact
            val g = if (ag != null && ak != null) {
                val ref = wb.gainsFor(ak)
                doubleArrayOf(ag[0] * target[0] / ref[0], 1.0, ag[2] * target[2] / ref[2])
            } else target
            b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            b.set(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
            b.set(CaptureRequest.COLOR_CORRECTION_GAINS, RggbChannelVector(g[0].toFloat(), 1f, 1f, g[2].toFloat()))
            // Re-use the colour matrix the camera's own AWB chose, so colours stay natural.
            b.set(CaptureRequest.COLOR_CORRECTION_TRANSFORM, awbTransform ?: IDENTITY)
        } else {
            b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }

        // Focus
        when (cfg.focus) {
            FocusMode.CONTINUOUS -> b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            FocusMode.MANUAL, FocusMode.INFINITY -> if (c.minFocusDiopters > 0f) {
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                val d = if (cfg.focus == FocusMode.INFINITY) 0f else cfg.focusDiopters.coerceIn(0f, c.minFocusDiopters)
                b.set(CaptureRequest.LENS_FOCUS_DISTANCE, d)
            } else {
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            }
        }
        val ois = characteristics?.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        if (ois != null && CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON in ois) {
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
        }
    }

    private val meterCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            if (++frameCounter % 5 != 0) return
            val c = caps ?: return
            var k = _metering.value.awbKelvin
            if (result.get(CaptureResult.CONTROL_AWB_MODE) == CaptureResult.CONTROL_AWB_MODE_AUTO) {
                result.get(CaptureResult.COLOR_CORRECTION_GAINS)?.let { g ->
                    val green = ((g.greenEven + g.greenOdd) / 2f).toDouble().coerceAtLeast(1e-3)
                    val norm = doubleArrayOf(g.red / green, 1.0, g.blue / green)
                    val exact = wb.kelvinForGains(norm[0], 1.0, norm[2])
                    awbGains = norm; awbKelvinExact = exact
                    k = exact.roundToInt()
                }
                result.get(CaptureResult.COLOR_CORRECTION_TRANSFORM)?.let { awbTransform = it }
            }
            val aeOn = result.get(CaptureResult.CONTROL_AE_MODE) != CaptureResult.CONTROL_AE_MODE_OFF
            if (!aeOn) { _metering.value = _metering.value.copy(awbKelvin = k); return }
            val iso = result.get(CaptureResult.SENSOR_SENSITIVITY) ?: return
            val exp = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: return
            val steps = result.get(CaptureResult.CONTROL_AE_EXPOSURE_COMPENSATION) ?: 0
            _metering.value = MeteringInfo(
                iso = iso, exposureNs = exp, evComp = steps * c.evStep, awbKelvin = k,
                focusDiopters = result.get(CaptureResult.LENS_FOCUS_DISTANCE) ?: 0f, valid = true,
            )
        }
    }

    /** Takes one still, or a burst of [frames] identical stills for night stacking. */
    suspend fun capture(cfg: ControlConfig, frames: Int, jpegOrientation: Int, withRaw: Boolean): StillResult {
        val s = session ?: error("Camera not ready")
        val d = device ?: error("Camera not ready")
        val jr = jpegReader ?: error("Camera not ready")
        val ch = characteristics ?: error("Camera not ready")
        drain()
        val rr = rawReader?.takeIf { withRaw && frames == 1 }

        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.addTarget(jr.surface)
        rr?.let { b.addTarget(it.surface) }
        applyControls(b, cfg, forPreview = false)
        b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation)
        b.set(CaptureRequest.JPEG_QUALITY, 95.toByte())
        ch.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)?.let {
            if (CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY in it)
                b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        }
        ch.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)?.let {
            if (CaptureRequest.EDGE_MODE_HIGH_QUALITY in it) b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
        }

        val results = Channel<TotalCaptureResult>(Channel.UNLIMITED)
        val callback = object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, result: TotalCaptureResult) {
                results.trySend(result)
            }
            override fun onCaptureFailed(s: CameraCaptureSession, r: CaptureRequest, failure: CaptureFailure) {
                Log.w(TAG, "capture failed: reason ${failure.reason}")
            }
        }
        val request = b.build()
        if (frames > 1) s.captureBurst(List(frames) { request }, callback, handler)
        else s.capture(request, callback, handler)

        val expMs = (cfg.manual?.exposureNs ?: 50_000_000L) / 1_000_000L
        val timeoutMs = 5_000L + frames * (expMs + 700L)
        return withTimeout(timeoutMs) {
            val list = ArrayList<ByteArray>(frames)
            repeat(frames) { list += jpegs.receive() }
            val result = results.tryReceive().getOrNull() ?: withTimeoutOrNull(1_500) { results.receive() }
            val raw = if (rr != null) withTimeoutOrNull(4_000) { raws.receive() } else null
            StillResult(list, raw, result, ch)
        }
    }

    private fun drain() {
        while (jpegs.tryReceive().isSuccess) Unit
        while (true) { val img = raws.tryReceive().getOrNull() ?: break; img.close() }
    }

    companion object {
        private const val TAG = "CameraController"
        private const val PREVIEW_MAX_EXPOSURE_NS = 66_000_000L // ~1/15 s
        private val IDENTITY = ColorSpaceTransform(intArrayOf(1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1))
    }
}
