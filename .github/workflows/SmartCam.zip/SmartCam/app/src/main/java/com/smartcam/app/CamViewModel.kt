package com.smartcam.app

import android.app.Application
import android.content.Context
import android.graphics.SurfaceTexture
import android.location.Location
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartcam.app.camera.CameraController
import com.smartcam.app.camera.ControlConfig
import com.smartcam.app.camera.PhotoProcessor
import com.smartcam.app.engine.ReferenceAnalyzer
import com.smartcam.app.engine.SettingsEngine
import com.smartcam.app.env.EnvSensors
import com.smartcam.app.env.WeatherService
import com.smartcam.app.model.CameraCaps
import com.smartcam.app.model.EnvironmentInfo
import com.smartcam.app.model.FocusMode
import com.smartcam.app.model.MeteringInfo
import com.smartcam.app.model.Preset
import com.smartcam.app.model.Recommendation
import com.smartcam.app.model.ReferenceProfile
import com.smartcam.app.model.SceneInfo
import com.smartcam.app.model.ShotSettings
import com.smartcam.app.util.Exposure
import com.smartcam.app.util.ImageStatsCalc
import com.smartcam.app.util.SunCalc
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

enum class Mode { SMART, MANUAL }

data class ManualState(
    val autoExposure: Boolean = false,
    val iso: Int = 100,
    val exposureNs: Long = 8_000_000L,
    val autoWb: Boolean = true,
    val wbKelvin: Int = 5200,
    val autoFocus: Boolean = true,
    val focusDiopters: Float = 0f,
)

data class UiState(
    val mode: Mode = Mode.SMART,
    val preset: Preset = Preset.AUTO,
    val cameras: List<CameraCaps> = emptyList(),
    val caps: CameraCaps? = null,
    val zoom: Float = 1f,
    val manual: ManualState = ManualState(),
    val rec: Recommendation? = null,
    val scene: SceneInfo = SceneInfo(),
    val metering: MeteringInfo = MeteringInfo(),
    val env: EnvironmentInfo = EnvironmentInfo(),
    val reference: ReferenceProfile? = null,
    val meterEv: Float = 0f,
    val rawEnabled: Boolean = false,
    val rawActive: Boolean = false,
    val keepOriginal: Boolean = true,
    val presetLooks: Boolean = false,
    val maxIso: Int = 3200,
    val busy: Boolean = false,
    val message: String? = null,
)

class CamViewModel(app: Application) : AndroidViewModel(app) {
    private val camera = CameraController(app)
    private val sensors = EnvSensors(app)
    private val weather = WeatherService(app)
    private val engine = SettingsEngine()
    private val engineLock = Mutex()
    private val prefs = app.getSharedPreferences("smartcam", Context.MODE_PRIVATE)

    private val _ui = MutableStateFlow(
        UiState(
            rawEnabled = prefs.getBoolean("raw", false),
            keepOriginal = prefs.getBoolean("keepOriginal", true),
            presetLooks = prefs.getBoolean("presetLooks", false),
            maxIso = prefs.getInt("maxIso", 3200),
        ),
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    @Volatile var deviceOrientation = 0
    private var texture: SurfaceTexture? = null
    private var started = false
    private var cameraId: String? = prefs.getString("camera", null)
    private var openJob: Job? = null
    private var envJob: Job? = null
    private var lastLocation: Location? = null
    private var prevLuma: FloatArray? = null
    private var motionEma = 0f

    init {
        viewModelScope.launch { camera.metering.collect { m -> _ui.update { it.copy(metering = m) } } }
        viewModelScope.launch {
            combine(sensors.lux, sensors.shake) { l, s -> l to s }.collect { (l, s) ->
                _ui.update { it.copy(env = it.env.copy(lux = l, shake = s)) }
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    fun onStart() {
        started = true
        sensors.start()
        if (texture != null) openCamera()
        startEnvironmentLoop()
    }

    fun onStop() {
        started = false
        sensors.stop()
        envJob?.cancel()
        openJob?.cancel()
        camera.close()
    }

    fun onSurfaceReady(t: SurfaceTexture) {
        texture = t
        if (started) openCamera()
    }

    fun onSurfaceDestroyed() {
        texture = null
        openJob?.cancel()
        camera.close()
    }

    override fun onCleared() {
        camera.release()
        sensors.stop()
    }

    private fun openCamera() {
        val t = texture ?: return
        openJob?.cancel()
        openJob = viewModelScope.launch {
            try {
                val cams = _ui.value.cameras.ifEmpty { withContext(Dispatchers.Default) { camera.listCameras() } }
                if (cams.isEmpty()) { _ui.update { it.copy(message = "No camera found") }; return@launch }
                val id = cameraId?.takeIf { i -> cams.any { it.id == i } }
                    ?: cams.firstOrNull { it.facingBack && it.label.startsWith("Wide") }?.id
                    ?: cams.first().id
                cameraId = id
                val wantRaw = _ui.value.rawEnabled
                val caps = camera.open(id, t, wantRaw)
                engineLock.withLock { engine.reset() }
                _ui.update { s ->
                    s.copy(
                        cameras = cams,
                        caps = caps,
                        rawActive = camera.rawActive,
                        zoom = 1f.coerceIn(caps.zoomMin, caps.zoomMax),
                        manual = s.manual.copy(
                            iso = s.manual.iso.coerceIn(caps.isoRange.first, caps.isoRange.last),
                            exposureNs = s.manual.exposureNs.coerceIn(caps.expRangeNs.first, caps.expRangeNs.last),
                        ),
                        message = when {
                            wantRaw && !camera.rawActive -> "RAW isn't available on this lens"
                            !caps.manualSensor -> "This lens has limited manual control"
                            else -> null
                        },
                    )
                }
                pushConfig()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(message = "Camera error: ${e.message}") }
            }
        }
    }

    /** Location → sun position every minute, weather every 30 minutes. */
    private fun startEnvironmentLoop() {
        envJob?.cancel()
        envJob = viewModelScope.launch {
            var lastWeather = 0L
            while (true) {
                if (lastLocation == null) lastLocation = runCatching { weather.location() }.getOrNull()
                val loc = lastLocation
                if (loc != null) {
                    val sun = SunCalc.info(loc.latitude, loc.longitude, System.currentTimeMillis())
                    _ui.update { it.copy(env = it.env.copy(sun = sun)) }
                    if (System.currentTimeMillis() - lastWeather > 30 * 60_000L) {
                        weather.fetch(loc.latitude, loc.longitude)?.let { w ->
                            lastWeather = System.currentTimeMillis()
                            _ui.update { it.copy(env = it.env.copy(weather = w)) }
                        }
                    }
                }
                delay(if (loc == null) 15_000L else 60_000L)
            }
        }
    }

    // ------------------------------------------------------------------ analysis

    /** Called ~2.5×/s with a small RGB thumbnail of the live preview. */
    fun onFrame(pixels: IntArray) {
        viewModelScope.launch(Dispatchers.Default) {
            engineLock.withLock {
                val stats = ImageStatsCalc.compute(pixels)
                val luma = ImageStatsCalc.lumaOf(pixels)
                motionEma = 0.6f * motionEma + 0.4f * ImageStatsCalc.motion(prevLuma, luma)
                prevLuma = luma
                val scene = SceneInfo(stats, motionEma)
                val s = _ui.value
                val caps = s.caps ?: return@withLock
                val rec = if (s.mode == Mode.SMART) {
                    engine.compute(
                        SettingsEngine.Input(
                            preset = s.preset, metering = s.metering, scene = scene, env = s.env, caps = caps,
                            reference = s.reference, maxIso = s.maxIso, zoom = s.zoom,
                            presetLooks = s.presetLooks, nowMillis = System.currentTimeMillis(),
                        ),
                    )
                } else s.rec
                _ui.update { it.copy(scene = scene, rec = rec, meterEv = SettingsEngine.meterOffsetEv(stats)) }
            }
            pushConfig()
        }
    }

    private fun manualConfig(s: UiState) = ControlConfig(
        manual = if (s.manual.autoExposure) null else ShotSettings(s.manual.iso, s.manual.exposureNs, null),
        evComp = 0f,
        wbKelvin = if (s.manual.autoWb) null else s.manual.wbKelvin,
        zoom = s.zoom,
        focus = if (s.manual.autoFocus) FocusMode.CONTINUOUS else FocusMode.MANUAL,
        focusDiopters = s.manual.focusDiopters,
    )

    private fun pushConfig() {
        val s = _ui.value
        if (s.caps == null) return
        val cfg = when (s.mode) {
            // Smart preview keeps AE/AWB running (so we keep measuring) with the engine's EV bias.
            Mode.SMART -> ControlConfig(evComp = s.rec?.previewEv ?: 0f, zoom = s.zoom)
            Mode.MANUAL -> manualConfig(s)
        }
        camera.setConfig(cfg)
    }

    // ------------------------------------------------------------------ capture

    fun capture() {
        val s = _ui.value
        val caps = s.caps ?: return
        if (s.busy) return
        _ui.update { it.copy(busy = true, message = null) }
        viewModelScope.launch {
            try {
                val rec = s.rec
                val (cfg, frames) = when (s.mode) {
                    Mode.SMART -> {
                        val shot = rec?.shot
                        ControlConfig(
                            manual = shot?.takeIf { caps.manualSensor },
                            evComp = rec?.previewEv ?: 0f,
                            wbKelvin = shot?.wbKelvin,
                            zoom = s.zoom,
                            focus = shot?.focus ?: FocusMode.CONTINUOUS,
                        ) to (shot?.stackFrames ?: 1)
                    }
                    Mode.MANUAL -> manualConfig(s) to 1
                }
                val look = if (s.mode == Mode.SMART) rec?.look else null
                if (frames > 1) _ui.update { it.copy(message = "Hold still… capturing $frames frames") }
                val still = camera.capture(cfg, frames, jpegOrientation(caps), s.rawActive)
                if (frames > 1 || look != null) _ui.update { it.copy(message = "Processing…") }
                val msg = withContext(Dispatchers.IO) { PhotoProcessor.process(getApplication(), still, look, s.keepOriginal) }
                _ui.update { it.copy(busy = false, message = msg) }
            } catch (e: CancellationException) {
                _ui.update { it.copy(busy = false) }
                throw e
            } catch (e: Throwable) {
                _ui.update { it.copy(busy = false, message = "Capture failed: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    private fun jpegOrientation(caps: CameraCaps): Int {
        val d = ((deviceOrientation + 45) / 90 * 90) % 360
        return if (caps.facingBack) (caps.sensorOrientation + d) % 360 else (caps.sensorOrientation - d + 360) % 360
    }

    // ------------------------------------------------------------------ user actions

    fun setMode(m: Mode) { _ui.update { it.copy(mode = m) }; pushConfig() }

    fun setPreset(p: Preset) {
        viewModelScope.launch { engineLock.withLock { engine.reset() } }
        _ui.update { it.copy(preset = p, mode = Mode.SMART) }
        pushConfig()
    }

    fun selectCamera(id: String) {
        cameraId = id
        prefs.edit().putString("camera", id).apply()
        openCamera()
    }

    fun setZoom(z: Float) { _ui.update { it.copy(zoom = z) }; pushConfig() }

    fun updateManual(f: (ManualState) -> ManualState) { _ui.update { it.copy(manual = f(it.manual)) }; pushConfig() }

    /** Copies the current smart recommendation into manual mode for fine-tuning. */
    fun smartToManual() {
        val shot = _ui.value.rec?.shot ?: return
        _ui.update {
            it.copy(
                mode = Mode.MANUAL,
                manual = it.manual.copy(
                    autoExposure = false, iso = shot.iso, exposureNs = shot.exposureNs,
                    autoWb = shot.wbKelvin == null, wbKelvin = shot.wbKelvin ?: it.manual.wbKelvin,
                ),
            )
        }
        pushConfig()
    }

    fun setRaw(on: Boolean) {
        prefs.edit().putBoolean("raw", on).apply()
        _ui.update { it.copy(rawEnabled = on) }
        openCamera()
    }

    fun setKeepOriginal(on: Boolean) { prefs.edit().putBoolean("keepOriginal", on).apply(); _ui.update { it.copy(keepOriginal = on) } }
    fun setPresetLooks(on: Boolean) { prefs.edit().putBoolean("presetLooks", on).apply(); _ui.update { it.copy(presetLooks = on) } }
    fun setMaxIso(v: Int) { prefs.edit().putInt("maxIso", v).apply(); _ui.update { it.copy(maxIso = v) } }

    fun setReference(uri: Uri) {
        _ui.update { it.copy(message = "Reading reference photo…") }
        viewModelScope.launch {
            try {
                val ref = ReferenceAnalyzer.analyze(getApplication(), uri)
                engineLock.withLock { engine.reset() }
                val exif = listOfNotNull(
                    ref.exifIso?.let { "ISO $it" },
                    ref.exifExposureS?.let { Exposure.formatShutter((it * 1e9).toLong()) },
                ).joinToString(", ")
                _ui.update {
                    it.copy(
                        reference = ref, preset = Preset.MATCH, mode = Mode.SMART,
                        message = "Matching reference" + if (exif.isNotEmpty()) " (shot at $exif)" else " (no camera data in file – matching by look)",
                    )
                }
                pushConfig()
            } catch (e: Exception) {
                _ui.update { it.copy(message = "Couldn't read photo: ${e.message}") }
            }
        }
    }

    fun clearReference() {
        _ui.update { it.copy(reference = null, preset = if (it.preset == Preset.MATCH) Preset.AUTO else it.preset) }
    }

    fun dismissMessage() { _ui.update { it.copy(message = null) } }
}
