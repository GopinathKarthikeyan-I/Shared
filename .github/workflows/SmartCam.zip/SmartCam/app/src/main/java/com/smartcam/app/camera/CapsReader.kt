package com.smartcam.app.camera

import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.ColorSpaceTransform
import android.util.Log
import android.util.Range
import android.util.Size
import com.smartcam.app.model.CameraCaps
import com.smartcam.app.util.WbModel
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Reads lens capabilities from Camera2 into our [CameraCaps] model. */
object CapsReader {
    private const val TAG = "CapsReader"

    /**
     * All usable lenses. Samsung lists the main ones in cameraIdList; some One UI versions also
     * expose extra lenses on unlisted ids, so a few are probed and de-duplicated by focal length.
     */
    fun listCameras(manager: CameraManager): List<CameraCaps> {
        val ids = LinkedHashSet<String>()
        runCatching { ids.addAll(manager.cameraIdList) }
        for (i in 0..9) ids.add(i.toString())
        val result = mutableListOf<CameraCaps>()
        for (id in ids) {
            val ch = runCatching { manager.getCameraCharacteristics(id) }.getOrNull() ?: continue
            val caps = runCatching { read(id, ch) }.onFailure { Log.w(TAG, "skip $id", it) }.getOrNull() ?: continue
            val dup = result.any { it.facingBack == caps.facingBack && abs(it.focal35 - caps.focal35) < 2f }
            if (!dup) result += caps
        }
        return result.sortedWith(compareByDescending<CameraCaps> { it.facingBack }.thenBy { it.focal35 })
    }

    fun read(id: String, ch: CameraCharacteristics): CameraCaps {
        val available = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
        val manualSensor = CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR in available
        val manualPost = CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING in available
        val hasRaw = CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW in available
        val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?: error("No stream configuration for camera $id")
        val jpeg = map.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width.toLong() * it.height }
            ?: error("No JPEG output for camera $id")
        val raw = if (hasRaw) map.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull { it.width.toLong() * it.height } else null
        val preview = choosePreview(map.getOutputSizes(SurfaceTexture::class.java) ?: arrayOf(Size(1440, 1080)), jpeg)

        val iso = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 1600)
        val exp = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(100_000L, 250_000_000L)
        val focal = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 5f
        val phys = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        val focal35 = if (phys != null && phys.width > 0) focal * 43.27f / hypot(phys.width, phys.height) else 26f
        val zoom = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) ?: Range(1f, 1f)
        val ev = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        val evStep = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat()?.takeIf { it > 0 } ?: (1f / 3f)
        val back = ch.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_FRONT
        val minFocus = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f

        return CameraCaps(
            id = id,
            label = label(focal35, back, id),
            facingBack = back,
            isoRange = iso.lower..iso.upper,
            expRangeNs = exp.lower..exp.upper,
            minFocusDiopters = minFocus,
            manualSensor = manualSensor,
            manualPostProcessing = manualPost,
            rawSize = raw,
            jpegSize = jpeg,
            previewSize = preview,
            focal35 = focal35,
            zoomMin = zoom.lower,
            zoomMax = zoom.upper,
            sensorOrientation = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90,
            evMinSteps = ev.lower,
            evMaxSteps = ev.upper,
            evStep = evStep,
            baseIso = iso.lower,
        )
    }

    private fun label(f35: Float, back: Boolean, id: String): String {
        val mm = f35.roundToInt()
        val kind = when {
            !back -> "Front"
            f35 < 20 -> "Ultra-wide"
            f35 < 35 -> "Wide"
            f35 < 120 -> "Tele ${(f35 / 24f).roundToInt()}x"
            else -> "Periscope ${(f35 / 24f).roundToInt()}x"
        }
        return "$kind ${mm}mm · id $id"
    }

    /** Same aspect as the photo, at most ~1440×1080 to keep preview smooth. */
    private fun choosePreview(sizes: Array<Size>, jpeg: Size): Size {
        val aspect = jpeg.width.toFloat() / jpeg.height
        val candidates = sizes.filter {
            abs(it.width.toFloat() / it.height - aspect) < 0.02f && it.width <= 1920 && it.height <= 1440
        }
        return candidates.maxByOrNull { it.width * it.height } ?: sizes.minByOrNull { abs(it.width - 1440) } ?: Size(1440, 1080)
    }

    /** Builds the calibrated Kelvin↔gains model, falling back to an sRGB approximation. */
    fun wbModel(ch: CameraCharacteristics): WbModel {
        val cm1 = ch.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM1)?.toArray() ?: return WbModel.fallback()
        val cm2 = ch.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM2)?.toArray()
        val i1 = ch.get(CameraCharacteristics.SENSOR_REFERENCE_ILLUMINANT1) ?: 21
        val i2 = ch.get(CameraCharacteristics.SENSOR_REFERENCE_ILLUMINANT2)?.toInt() ?: i1
        val cc1 = ch.get(CameraCharacteristics.SENSOR_CALIBRATION_TRANSFORM1)?.toArray()
        val cc2 = ch.get(CameraCharacteristics.SENSOR_CALIBRATION_TRANSFORM2)?.toArray()
        val model = WbModel(cm1, cm2, WbModel.illuminantKelvin(i1), WbModel.illuminantKelvin(i2), cc1, cc2)
        // Sanity check: the round trip must be consistent, otherwise use the fallback.
        val g = model.gainsFor(5000.0)
        val back = model.kelvinForGains(g[0], g[1], g[2])
        val sane = g.all { it.isFinite() && it in 0.2..8.0 } && abs(back - 5000) < 400
        return if (sane) model else WbModel.fallback()
    }

    private fun ColorSpaceTransform.toArray() = DoubleArray(9) { i -> getElement(i % 3, i / 3).toDouble() }
}
