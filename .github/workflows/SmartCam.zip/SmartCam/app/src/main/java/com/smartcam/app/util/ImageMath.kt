package com.smartcam.app.util

import com.smartcam.app.model.ImageStats
import com.smartcam.app.model.Look
import com.smartcam.app.model.SunInfo
import com.smartcam.app.model.SunPhase
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Statistics over ARGB pixels (as returned by Bitmap.getPixels). Pure Kotlin. */
object ImageStatsCalc {
    private val LIN = FloatArray(256) { ColorMath.srgbToLinear(it / 255f) }

    fun compute(pixels: IntArray): ImageStats {
        val n = pixels.size
        if (n == 0) return ImageStats()
        val hist = IntArray(256)
        var sumY = 0.0; var sumY2 = 0.0; var sumSat = 0.0
        var lr = 0.0; var lg = 0.0; var lb = 0.0
        var hi = 0; var lo = 0
        for (p in pixels) {
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val y = (0.299f * r + 0.587f * g + 0.114f * b)
            val yi = y.toInt().coerceIn(0, 255)
            hist[yi]++
            val yf = y / 255.0
            sumY += yf; sumY2 += yf * yf
            val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
            if (mx > 0) sumSat += (mx - mn).toDouble() / mx
            lr += LIN[r]; lg += LIN[g]; lb += LIN[b]
            if (mx >= 250) hi++
            if (mx <= 6) lo++
        }
        val mean = sumY / n
        val std = sqrt(max(0.0, sumY2 / n - mean * mean))
        return ImageStats(
            meanLuma = mean.toFloat(),
            stdLuma = std.toFloat(),
            p05 = percentile(hist, n, 0.05f),
            p95 = percentile(hist, n, 0.95f),
            meanSat = (sumSat / n).toFloat(),
            castKelvin = ColorMath.castKelvin(lr / n, lg / n, lb / n),
            highlightClip = hi.toFloat() / n,
            shadowClip = lo.toFloat() / n,
        )
    }

    private fun percentile(hist: IntArray, n: Int, q: Float): Float {
        val target = (n * q).toInt()
        var acc = 0
        for (i in 0 until 256) {
            acc += hist[i]
            if (acc >= target) return i / 255f
        }
        return 1f
    }

    /** Mean absolute difference between two luma thumbnails, 0..1. */
    fun motion(prev: FloatArray?, cur: FloatArray): Float {
        if (prev == null || prev.size != cur.size) return 0f
        var s = 0.0
        for (i in cur.indices) s += abs(cur[i] - prev[i])
        return (s / cur.size).toFloat()
    }

    fun lumaOf(pixels: IntArray) = FloatArray(pixels.size) {
        val p = pixels[it]
        (0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)) / 255f
    }
}

/** Solar position (NOAA-style low precision, good to ~0.5°). */
object SunCalc {
    fun elevation(latDeg: Double, lonDeg: Double, timeMillis: Long): Double {
        val d = timeMillis / 86_400_000.0 + 2440587.5 - 2451545.0
        val g = Math.toRadians((357.529 + 0.98560028 * d) % 360)
        val q = (280.459 + 0.98564736 * d) % 360
        val l = Math.toRadians(q + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val e = Math.toRadians(23.439 - 0.00000036 * d)
        val ra = atan2(cos(e) * sin(l), cos(l))
        val dec = asin(sin(e) * sin(l))
        val gmstHours = ((18.697374558 + 24.06570982441908 * d) % 24 + 24) % 24
        val lst = Math.toRadians(((gmstHours * 15 + lonDeg) % 360 + 360) % 360)
        val ha = lst - ra
        val lat = Math.toRadians(latDeg)
        return Math.toDegrees(asin(sin(lat) * sin(dec) + cos(lat) * cos(dec) * cos(ha)))
    }

    fun phase(elevationDeg: Double): SunPhase = when {
        elevationDeg < -6 -> SunPhase.NIGHT
        elevationDeg < -4 -> SunPhase.BLUE_HOUR
        elevationDeg < 6 -> SunPhase.GOLDEN_HOUR
        elevationDeg < 50 -> SunPhase.DAY
        else -> SunPhase.HIGH_SUN
    }

    fun info(lat: Double, lon: Double, timeMillis: Long): SunInfo {
        val el = elevation(lat, lon, timeMillis)
        return SunInfo(el, phase(el))
    }
}

/** Exposure value helpers: stop rounding and display formatting. */
object Exposure {
    private val SHUTTERS_S = doubleArrayOf(
        1 / 12000.0, 1 / 8000.0, 1 / 6400.0, 1 / 5000.0, 1 / 4000.0, 1 / 3200.0, 1 / 2500.0, 1 / 2000.0,
        1 / 1600.0, 1 / 1250.0, 1 / 1000.0, 1 / 800.0, 1 / 640.0, 1 / 500.0, 1 / 400.0, 1 / 320.0,
        1 / 250.0, 1 / 200.0, 1 / 160.0, 1 / 125.0, 1 / 100.0, 1 / 80.0, 1 / 60.0, 1 / 50.0, 1 / 40.0,
        1 / 30.0, 1 / 25.0, 1 / 20.0, 1 / 15.0, 1 / 13.0, 1 / 10.0, 1 / 8.0, 1 / 6.0, 1 / 5.0, 1 / 4.0,
        0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.3, 1.6, 2.0, 2.5, 3.2, 4.0, 5.0, 6.0, 8.0, 10.0, 13.0, 15.0,
        20.0, 25.0, 30.0,
    )
    private val ISOS = intArrayOf(
        50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500,
        3200, 4000, 5000, 6400, 8000, 10000, 12800,
    )

    fun roundShutterNs(ns: Long): Long {
        val s = ns / 1e9
        val best = SHUTTERS_S.minByOrNull { abs(ln(it) - ln(s)) } ?: s
        return (best * 1e9).toLong()
    }

    fun roundIso(iso: Int): Int = ISOS.minByOrNull { abs(ln(it.toDouble()) - ln(iso.toDouble().coerceAtLeast(1.0))) } ?: iso

    fun formatShutter(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.3) {
            val v = if (s >= 10) s.roundToInt().toString() else ((s * 10).roundToInt() / 10.0).toString().removeSuffix(".0")
            "$v\""
        } else "1/${(1 / s).roundToInt()}"
    }

    fun formatEv(ev: Float): String {
        val r = (ev * 10).roundToInt() / 10f
        return when {
            r > 0 -> "+$r"
            r < 0 -> "$r"
            else -> "0"
        }
    }

    /** Exposure "amount" ISO × seconds, convenient for redistributing between ISO and shutter. */
    fun log2(x: Double) = ln(x) / ln(2.0)
    fun pow2(x: Double) = 2.0.pow(x)
}

/** Builds a 4×5 Android ColorMatrix array for a [Look]. Pure so it can be tested. */
object LookMatrix {
    fun of(look: Look): FloatArray {
        var m = identity()
        // Saturation (Rec.601 luma weights)
        val s = look.saturation
        val lr = 0.299f; val lg = 0.587f; val lb = 0.114f
        m = concat(
            floatArrayOf(
                lr * (1 - s) + s, lg * (1 - s), lb * (1 - s), 0f, 0f,
                lr * (1 - s), lg * (1 - s) + s, lb * (1 - s), 0f, 0f,
                lr * (1 - s), lg * (1 - s), lb * (1 - s) + s, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            ), m,
        )
        // Warmth / tint channel scaling
        val wr = 1f + 0.10f * look.warmth
        val wb = 1f - 0.10f * look.warmth
        val tg = 1f - 0.07f * look.tint
        m = concat(scale(wr, tg, wb), m)
        // Contrast around mid grey + brightness offset
        val c = look.contrast
        val off = 127.5f * (1 - c) + look.brightness * 255f
        m = concat(
            floatArrayOf(
                c, 0f, 0f, 0f, off,
                0f, c, 0f, 0f, off,
                0f, 0f, c, 0f, off,
                0f, 0f, 0f, 1f, 0f,
            ), m,
        )
        return m
    }

    private fun identity() = floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    private fun scale(r: Float, g: Float, b: Float) = floatArrayOf(r, 0f, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f)

    /** Returns a·b (apply b first, then a), both 4×5 with implicit last row [0 0 0 0 1]. */
    fun concat(a: FloatArray, b: FloatArray): FloatArray {
        val r = FloatArray(20)
        for (i in 0 until 4) {
            for (j in 0 until 5) {
                var v = 0f
                for (k in 0 until 4) v += a[i * 5 + k] * b[k * 5 + j]
                if (j == 4) v += a[i * 5 + 4]
                r[i * 5 + j] = v
            }
        }
        return r
    }

    /** Apply matrix to one ARGB pixel (used by the stacker/JVM tests). */
    fun apply(m: FloatArray, argb: Int): Int {
        val r = ((argb shr 16) and 0xFF).toFloat()
        val g = ((argb shr 8) and 0xFF).toFloat()
        val b = (argb and 0xFF).toFloat()
        fun ch(row: Int) = (m[row * 5] * r + m[row * 5 + 1] * g + m[row * 5 + 2] * b + m[row * 5 + 4]).roundToInt().coerceIn(0, 255)
        return (argb and 0xFF000000.toInt()) or (ch(0) shl 16) or (ch(1) shl 8) or ch(2)
    }
}
