# SmartCam: auto camera settings for Galaxy S21 Ultra / S25 Ultra

A personal Android camera app that picks ISO, shutter speed, white balance, EV and focus from:

- **Live light**: the camera's own metering plus a histogram check (protects bright skies, lifts deep shadows)
- **Weather**: cloud, fog, rain and snow from Open-Meteo (free, no API key), using coarse location
- **Sun position**: golden hour, blue hour, harsh midday sun and night, calculated on the phone
- **Ambient light sensor**: tells indoor from outdoor, so weather is ignored indoors
- **Gyroscope**: detects a tripod or a phone resting on something and allows long exposures
- **Subject motion**: compares frames and switches to a faster shutter for moving subjects
- **Lens**: hand-shake limit based on focal length and zoom (ultra-wide, wide, 3x, 10x)

## Features

| Feature | What it does |
|---|---|
| Smart mode | Presets: Smart Auto, Portrait, Landscape, Night, Sports, Golden hour |
| Match photo | Pick any photo. Reads its EXIF (ISO, shutter) if present and its brightness, colour cast, contrast and saturation. Sets the camera to match, then applies the remaining "look" after capture |
| Night | On a tripod: long exposure at low ISO. Handheld: 6-frame burst, aligned and averaged (about 2.5× less noise) |
| Manual mode | ISO, shutter (up to 30 s), Kelvin WB, manual focus, with a live exposure meter. "Fine-tune →" copies the smart values into manual |
| Pro advice | Values to type into Samsung Camera → Pro mode (ISO, Speed, WB, focus, metering), plus Gallery edit values for the look. Opens Samsung Camera |
| RAW | Optional DNG saved alongside the JPEG (Settings) |
| Saving | Pictures/SmartCam. Keeps the untouched original when a look or stack is applied (optional) |

## Build and install (about 15 minutes the first time)

1. Install **Android Studio** (latest) on your Windows PC.
2. Unzip this folder, then in Android Studio choose **File → Open** and select the `SmartCam` folder. Let Gradle sync; it downloads the SDK and libraries.
3. On the phone, turn on Developer options: Settings → About phone → Software information → tap **Build number** 7 times. Then Settings → Developer options → turn on **USB debugging**.
4. Connect the phone by USB, accept the prompt, pick it in the device dropdown and press **Run ▶**.
   - Wireless option: Developer options → Wireless debugging → Pair, then in Android Studio use "Pair Devices Using Wi-Fi".
5. To get an APK file for the second phone: **Build → Build App Bundle(s)/APK(s) → Build APK(s)**. Copy `app/build/outputs/apk/debug/app-debug.apk` to the other phone and open it to install (allow "Install unknown apps").

Allow Camera and Location (location is only used for weather and sun position).

## Honest limitations

- Third-party apps don't get Samsung's own processing (Night mode's multi-frame AI, Scene Optimizer, some HDR). In tricky light, the Pro advice screen gives settings for Samsung's own camera instead.
- Samsung decides which lenses third-party apps can open. The app lists every lens it can access. Zoom on the main camera switches lenses automatically where Samsung allows it. The S25 Ultra exposes more than the S21 Ultra.
- The light sensor is on the front of the phone, so it reads the light where you're standing, not the scene. It's only used as an indoor/outdoor hint.
- The preview shows the camera's auto colour. The smart white balance and "look" are applied to the saved photo.
- Night stacking corrects hand-shake movement but not rotation, and can't fix subjects that move between frames.

## Code map

```
app/src/main/java/com/smartcam/app/
  MainActivity.kt          permissions, orientation
  CamViewModel.kt          state, ties everything together
  ui/CameraScreen.kt       Compose UI: viewfinder, presets, manual sliders, dialogs
  camera/CameraController  Camera2: preview, manual controls, burst, RAW
  camera/CapsReader        lens capabilities + colour calibration
  camera/PhotoProcessor    night stack alignment/averaging, looks, EXIF, DNG, MediaStore
  engine/SettingsEngine    the decision logic (pure Kotlin, unit-tested)
  engine/ReferenceAnalyzer reads the "match this photo" image
  env/Environment.kt       light sensor, gyro, location, weather
  util/                    colour science (Kelvin ↔ sensor gains), sun position, alignment
```

Tuning knobs are in `SettingsEngine.kt`, such as weather EV offsets, warmth shifts and the hand-shake limit.
